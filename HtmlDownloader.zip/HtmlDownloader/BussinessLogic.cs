﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace HtmlDownloader
{
    public class BussinessLogic
    {
        int i = 1;
        List<Uri> uris = new List<Uri>();
        /// <summary>
        /// Downlooads the provided link and sub links on local disk
        /// </summary>
        /// <param name="url"></param>
        /// <returns>Error</returns>
        public async Task<Error> DownloadLink(string url, string index = "1", string downloadPath = "")
        {
            Error error = new Error();
            Utilty utilty = new Utilty();
            if (!String.IsNullOrEmpty(utilty.ValidateUrl(url)))//validates the provided URL
            {
                error.ErrorMessage = "Invalid Url! Please try again with correct URL.";
                error.ErrorCode = 101;
                return error;
            }

            Utilty.StopAnimation();
            Console.WriteLine("Downloading: " + url);
            Utilty.StartAnimation(50);


            downloadPath = Path.Combine(downloadPath, i++.ToString());// add a subdirectory with incrementing number to maintain the heirarchy

            if (string.IsNullOrEmpty(downloadPath) || i == 2)
                downloadPath = ConfigurationManager.AppSettings["downloadPath"] + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_fff");// add timestamp to the path name

            try
            {

                string Page = DownloadHtml(url);// Download the HTML source code
                if (Page == null)
                {
                    error.ErrorMessage = "Unable to download the HTML source code.";
                    return error;
                }
                uris.Add(new Uri(url));// Add the processed URL to a list to track it 

                if (!await SaveToFile(downloadPath, url, Page, index))// Save the HTML source code to the disk
                {
                    Utilty.StopAnimation();
                    error.ErrorMessage = "Unable to save the file";
                    return error;
                }

                Regex regex = new Regex(@"href\s*=\s*(?:[""'](?<1>[^""']*)[""']|(?<1>[^>\s]+))");// regex to check if the HTML contains any link
                MatchCollection matchCollection = regex.Matches(Page); // store in this object if there are any links

                foreach (Match match in matchCollection) // iterate all the links in the file
                {

                    if (match.Groups[1].Value.Contains("https")) // only secured links will be downloaded
                    {

                        if (uris.Contains(new Uri(match.Groups[1].Value)))// if the url already exists in the processed URLs list, skip it to avoid the infinite loop
                            continue;

                        await DownloadLink(match.Groups[1].Value, i.ToString(), downloadPath); //recursion
                    }


                }





            }
            catch (Exception ex)
            {
                error.ErrorMessage = ex.Message;
                return error;
            }
            return null;


        }



        public string DownloadHtml(string url)
        {
            try
            {
                HttpClient client = new HttpClient();
                using (HttpResponseMessage response = client.GetAsync(url).Result)
                {
                    using (HttpContent httpContent = response.Content)
                    {

                        string result = httpContent.ReadAsStringAsync().Result;// read HTML into a string
                        return result;


                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }



        static async Task<bool> SaveToFile(string path, string name, string content, string index)
        {
            try
            {
                //path = Path.Combine(path, index);
                //if (name.ToLower().Contains("www"))
                //    name = name.Substring(name.IndexOf("www"));//remove any part before www

                if (name.Contains(@"://"))
                {
                    name = name.Substring(name.IndexOf(@"://"));// remove the part of the url that is not valid for file name
                    name = name.Replace(@"://", string.Empty);
                    if(name.Contains(@"/"))
                    name = name.Substring(0, name.IndexOf('/'));

                }

                if (index == "1")
                    name = name + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_fff");
                else
                    name = index + "_Timestamp" + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_fff");



                if (!Directory.Exists(path)) // create the directory if does not exist
                    Directory.CreateDirectory(path);
                string fullFileName = name + ".html";

                string fullPath = Path.Combine(path, fullFileName);
                using (FileStream fs = File.Create(fullPath))
                {

                    byte[] contentBytes = new UTF8Encoding(true).GetBytes(content);
                    await fs.WriteAsync(contentBytes, 0, contentBytes.Length);// write to the file
                }
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }


        }
    }
}
