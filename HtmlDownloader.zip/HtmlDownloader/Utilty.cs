﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HtmlDownloader
{
    public class Utilty
    {
        /// <summary>
        /// Validates the provided URL.
        /// </summary>
        /// <param name="url"></param>
        /// <returns>Error message.</returns>
        /// 
        public string ValidateUrl(string url)
        {

            Uri uriuriOutput = null;
            try
            {
                bool isValid = Uri.TryCreate(url, UriKind.Absolute, out uriuriOutput);

                if (isValid && uriuriOutput != null)
                    return string.Empty;
                else
                    return "URL is invalid! Kindly check the URL and try again.";
            }
            catch (Exception ex)
            {
                return "Could not validate the URL! Please try again.";
            }




        }


        public static string baseUrl = "";


        private static System.ComponentModel.BackgroundWorker spinner = initialiseBackgroundWorker();

        private static int spinnerPosition = 25;
        private static int spinWait = 25;
        private static bool isRunning;

        public static bool IsRunning { get { return isRunning; } }


        private static System.ComponentModel.BackgroundWorker initialiseBackgroundWorker()
        {
            System.ComponentModel.BackgroundWorker obj = new System.ComponentModel.BackgroundWorker();
            obj.WorkerSupportsCancellation = true;

            obj.DoWork += delegate
           {

               spinnerPosition = Console.CursorLeft;
               while (!obj.CancellationPending)
               {
                        //characters to iterate through during animation
                        char[] spinChars = new char[] { '|', '/', '-', '\\' };
                        //iterate through animation character array
                        foreach (char spinChar in spinChars)
                   {
                       Console.CursorLeft = spinnerPosition;

                            //write the current character to the console
                            Console.Write(spinChar);
                            //pause for smooth animation - set by the start method
                            System.Threading.Thread.Sleep(spinWait);

                   }

               }

           };

            return obj;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="spinWait"></param>
        public static void StartAnimation(int spinWait)
        {
            //Set the running flag
            isRunning = true;
            //process spinwait value            
            //start the animation unless already started

            if (!spinner.IsBusy)
                spinner.RunWorkerAsync();

            else throw new InvalidOperationException("Cannot start spinner whilst spinner is already running");

        }



        /// <summary>

        /// Overloaded Start method with default wait value

        /// </summary>

        public static void Start() { StartAnimation(25); }


        public static void StopAnimation()
        {
            //Stop the animation
            spinner.CancelAsync();
            //wait for cancellation to complete

            while (spinner.IsBusy) System.Threading.Thread.Sleep(100);
            //reset the cursor position

            Console.CursorLeft = spinnerPosition;
            //set the running flag
            isRunning = false;

        }



    }
}
