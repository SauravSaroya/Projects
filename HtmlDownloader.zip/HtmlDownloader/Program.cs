﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HtmlDownloader
{
    class Program
    {

        static int timeout =Convert.ToInt32( ConfigurationManager.AppSettings["Timeout"]);// Load default URL from config
        private static readonly Timer _timer =  new Timer(o => Environment.Exit(0), null, timeout, Timeout.Infinite);// Stop the application after provided timeout to prevent the application from becoming a long running job
   


        static void Main(string[] args)
        {


            Task task = MainAsync(args);//An attempt to make the app asynchronous
            task.Wait();

        }

        static async Task MainAsync(string[] args)
        {


            string url;
            _ = new Utilty();
            try
            {
                if (args != null && args.Length > 0)// if application needs to be excecuted from a task scheduler
                {
                    url = args[0].Trim();


                    BussinessLogic bussinessLogic = new BussinessLogic();

                    Error downloadError = await bussinessLogic.DownloadLink(url);// This method does all the work

                    if (downloadError == null)// if no error show success message
                        Console.WriteLine("Downloaded " + url + " Successfully!");
                    else// else show error message
                        Console.WriteLine(downloadError.ErrorMessage);

                    Utilty.StopAnimation();// stop animation if not already done
                    Console.ReadLine();
                }
                else
                {
                    url = ConfigurationManager.AppSettings["defaultUrl"];// Load default URL from config
                    Console.WriteLine("Hi there! Please type the link that you want to download or press Space to download " + url);

                    ConsoleKeyInfo key = Console.ReadKey();

                    if (key.Key == ConsoleKey.Spacebar)//Give user an option to enter the URL manually by pressing sapace bar
                    {


                        BussinessLogic bussinessLogic = new BussinessLogic();

                        Error downloadError = await bussinessLogic.DownloadLink(url);// This method does all the work

                        if (downloadError == null)// if no error show success message
                            Console.WriteLine("Downloaded " + url + " Successfully!");
                        else// else show error message
                            Console.WriteLine(downloadError.ErrorMessage);

                        Utilty.StopAnimation();// stop animation if not already done
                        Console.ReadLine();

                    }
                    else
                    {

                        url = key.Key + Console.ReadLine();// Read input, include the already pressed key           

                        BussinessLogic bussinessLogic = new BussinessLogic();

                        Error downloadError = await bussinessLogic.DownloadLink(url);
                        if (downloadError == null)
                            Console.WriteLine("Downloaded " + url + " Successfully!");
                        else
                            Console.WriteLine(downloadError.ErrorMessage);
                        Utilty.StopAnimation();
                        Console.ReadLine();

                    }





                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Very unexpected error has occured!");
                Console.WriteLine(ex.Message);

            }
        }
    }
}
